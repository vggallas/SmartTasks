package com.example.smarttasks;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroTarefaActivity extends AppCompatActivity {

    private EditText editTitulo, editDescricao, editData;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_tarefa);

        editTitulo = findViewById(R.id.editTitulo);
        editDescricao = findViewById(R.id.editDescricao);
        editData = findViewById(R.id.editData);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(view -> {
            String titulo = editTitulo.getText().toString();
            String descricao = editDescricao.getText().toString();
            String data = editData.getText().toString();

            if (titulo.isEmpty() || descricao.isEmpty() || data.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            } else {
                Tarefa tarefa = new Tarefa(titulo, descricao, data);
                Intent intent = new Intent();
                intent.putExtra("tarefa", tarefa);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}

