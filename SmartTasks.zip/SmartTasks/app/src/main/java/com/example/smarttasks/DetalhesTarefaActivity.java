package com.example.smarttasks;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalhesTarefaActivity extends AppCompatActivity {

    private TextView tvTituloDetalhe;
    private TextView tvDescricaoDetalhe;
    private TextView tvDataDetalhe;
    private TextView tvPrioridadeDetalhe;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_tarefa);

        tvTituloDetalhe = findViewById(R.id.tvTituloDetalhe);
        tvDescricaoDetalhe = findViewById(R.id.tvDescricaoDetalhe);
        tvDataDetalhe = findViewById(R.id.tvDataDetalhe);
        tvPrioridadeDetalhe = findViewById(R.id.tvPrioridadeDetalhe);

        Tarefa tarefa = getIntent().getParcelableExtra("tarefa");

        if (tarefa != null) {
            tvTituloDetalhe.setText(tarefa.getTitulo());
            tvDescricaoDetalhe.setText(tarefa.getDescricao());
            tvDataDetalhe.setText(tarefa.getData());
            tvPrioridadeDetalhe.setText(tarefa.getPrioridade());
        }
    }
}
