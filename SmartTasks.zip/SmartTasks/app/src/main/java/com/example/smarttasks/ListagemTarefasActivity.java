package com.example.smarttasks;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListagemTarefasActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TarefaAdapter tarefaAdapter;
    private ArrayList<Tarefa> listaTarefas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listagem_tarefas);

        recyclerView = findViewById(R.id.recyclerView); // Alterado para R.id.recyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Exemplo de tarefas simuladas (futuramente serão passadas via intent ou persistência)
        listaTarefas = new ArrayList<>();
        listaTarefas.add(new Tarefa("Estudar Java", "Revisar conceitos para prova", "2025-04-23"));
        listaTarefas.add(new Tarefa("Projeto Android", "Finalizar funcionalidade de urgência", "2025-04-25"));

        tarefaAdapter = new TarefaAdapter(listaTarefas, tarefa -> {
            Intent intent = new Intent(ListagemTarefasActivity.this, DetalhesTarefaActivity.class);
            intent.putExtra("tarefa", tarefa);
            startActivity(intent);
        });

        recyclerView.setAdapter(tarefaAdapter);
    }
}