package com.example.smarttasks;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Oculta a ActionBar padrão da Activity
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        findViewById(R.id.buttonCadastro).setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CadastroTarefaActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.buttonListagem).setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ListagemTarefasActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.buttonCompartilhar).setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "SmartTasks - Gerenciador de Tarefas");
            intent.putExtra(Intent.EXTRA_TEXT, "Conheça o app SmartTasks!");
            startActivity(Intent.createChooser(intent, "Compartilhar via"));
        });

        findViewById(R.id.buttonAnalise).setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AnalisadorTarefaActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.buttonAcessarSite).setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://institucional.ifrs.edu.br/rolante/"));
            startActivity(intent);
        });
    }
}