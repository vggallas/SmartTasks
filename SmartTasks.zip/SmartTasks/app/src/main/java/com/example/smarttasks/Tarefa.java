package com.example.smarttasks;

import android.os.Parcel;
import android.os.Parcelable;

public class Tarefa implements Parcelable {
    private String titulo;
    private String descricao;
    private String data;
    private String prioridade;

    public Tarefa(String titulo, String descricao, String data) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.data = data;
        this.prioridade = "Normal"; // Definido como "Normal" por padrão
    }

    // Construtor Parcelable
    protected Tarefa(Parcel in) {
        titulo = in.readString();
        descricao = in.readString();
        data = in.readString();
        prioridade = in.readString();
    }

    // Getters e Setters
    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getData() {
        return data;
    }

    public String getPrioridade() {
        return prioridade;
    }

    // Setter da Prioridade
    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    // Implementação do Parcelable
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(titulo);
        parcel.writeString(descricao);
        parcel.writeString(data);
        parcel.writeString(prioridade);
    }

    public static final Parcelable.Creator<Tarefa> CREATOR = new Parcelable.Creator<Tarefa>() {
        @Override
        public Tarefa createFromParcel(Parcel in) {
            return new Tarefa(in); // Chama o construtor Parcelable
        }

        @Override
        public Tarefa[] newArray(int size) {
            return new Tarefa[size];
        }
    };
}