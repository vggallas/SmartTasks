package com.example.smarttasks;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TarefaAdapter extends RecyclerView.Adapter<TarefaAdapter.TarefaViewHolder> {
    private List<Tarefa> tarefas;
    private OnClickListener listener;

    public TarefaAdapter(List<Tarefa> tarefas, OnClickListener listener) {
        this.tarefas = tarefas;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TarefaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tarefa, parent, false);
        return new TarefaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TarefaViewHolder holder, int position) {
        Tarefa tarefa = tarefas.get(position);
        holder.titulo.setText(tarefa.getTitulo());
        holder.descricao.setText(tarefa.getDescricao());
        holder.data.setText(tarefa.getData());
        holder.prioridade.setText(tarefa.getPrioridade());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClick(tarefa);
            }
        });
    }

    @Override
    public int getItemCount() {
        return tarefas.size();
    }

    public class TarefaViewHolder extends RecyclerView.ViewHolder {
        TextView titulo;
        TextView descricao;
        TextView data;
        TextView prioridade;

        public TarefaViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.tituloTarefa);
            descricao = itemView.findViewById(R.id.descricaoTarefa);
            data = itemView.findViewById(R.id.dataTarefa);
            prioridade = itemView.findViewById(R.id.prioridadeTarefa);
        }
    }

    public interface OnClickListener {
        void onClick(Tarefa tarefa);
    }
}